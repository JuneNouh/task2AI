import pandas as pd

data = {
  "total_bill": [16.99, 10.34, 21.01, 23.68, 24.59],
  "tip": [1.01, 1.66, 3.50, 3.31, 3.61],
  "sex": ["Female", "Male", "Male", "Male", "Female"]
}

#load data into a DataFrame object:
df = pd.DataFrame(data)
df.to_csv('tips.csv', index=False)
print(df["total_bill"].mean())
print(df["tip"].max())
