import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('miasta.csv', index_col=False)

new_data = {
    "Rok": 2010,
    "Gdansk": 460,
    "Poznan": 555,
    "Szczecin": 405
}

df.iloc[-1] = new_data
df.to_csv('miasta.csv', index=True)

plt.plot(df["Rok"], df["Gdansk"], marker='o', color='r')
plt.plot(df["Rok"], df["Poznan"], marker='o', color='b')
plt.plot(df["Rok"], df["Szczecin"], marker='o', color='g')
plt.title("Demography of 3 cities in Poland")
plt.xlabel("Year")
plt.ylabel("Number of people")
plt.show()

print(df.to_string())
